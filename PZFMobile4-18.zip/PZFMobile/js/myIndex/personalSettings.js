getPhone();
function getPhone(){//获取手机号
	const myINdexPhone = getUserData("phone");
	$("#phoneNumber").html(myINdexPhone);
}
